import { Component } from '@angular/core';

@Component({
  selector: 'app-barra-busqueda',
  standalone: true,
  imports: [],
  templateUrl: './barra-busqueda.component.html',
  styles: ''
})
export class BarraBusquedaComponent {

}
