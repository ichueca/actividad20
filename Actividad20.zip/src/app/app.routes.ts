import { Routes } from '@angular/router';
import { ListaEpisodiosComponent } from '../componentes/lista-episodios/lista-episodios.component';
import { ProgramaComponent } from '../componentes/programa/programa.component';

export const routes: Routes = [
  {path:'episodios', component: ListaEpisodiosComponent},
  {path:'programas/:id', component: ProgramaComponent},
  {path:'**', redirectTo:"episodios"}
];
